"""
Skenario dan misi simulator.
Terjemahan dari src/engine/scenarios.ts pada versi web.

Kondisi kapal disimpan dalam satu dictionary (sebut saja s). Contoh cara pakai:
    s = SCENARIOS["tropical"]["buat_kondisi"]()
    print(s["ht_outlet_temp"])
"""


def buat_pompa(**override):
    """
    Buat 6 pompa (SW, LT, HT masing-masing 2 unit).
    Contoh: buat_pompa(sw1={"running": False}) untuk mematikan pompa SW #1.
    """
    daftar = [
        # id, nama, sirkuit, nyala dari awal?, kapasitas (m3/h)
        ("sw1", "Pompa Air Laut #1 (Utama)", "sw", True, 420),
        ("sw2", "Pompa Air Laut #2 (Cadangan)", "sw", False, 420),
        ("lt1", "Pompa Air Tawar LT #1", "lt", True, 360),
        ("lt2", "Pompa Air Tawar LT #2", "lt", False, 360),
        ("ht1", "Pompa Air Tawar HT #1", "ht", True, 240),
        ("ht2", "Pompa Air Tawar HT #2", "ht", False, 240),
    ]
    pompa = {}
    for id_pompa, nama, sirkuit, nyala, kapasitas in daftar:
        ubah = override.get(id_pompa, {})
        pompa[id_pompa] = {
            "id": id_pompa,
            "name": nama,
            "circuit": sirkuit,
            "running": ubah.get("running", nyala),
            "tripped": ubah.get("tripped", False),
            "valve_open": ubah.get("valve_open", True),
            "valve_pct": ubah.get("valve_pct", 100),
            "flow_rate": 0,
            "rated_flow": kapasitas,
            "pressure": 0,
        }
    return pompa


def alarm_awal(tingkat, sumber, pesan, acknowledged=False):
    return {"waktu": 0, "tingkat": tingkat, "sumber": sumber, "pesan": pesan, "acknowledged": acknowledged}


def kondisi_dasar(scenario_id, **isi):
    """Nilai-nilai yang sama di semua skenario. Sisanya diisi/ditimpa lewat **isi."""
    s = {
        "running": True,
        "speed_multiplier": 1,
        "elapsed_seconds": 0,
        "scenario_id": scenario_id,
        "sea_chest_mode": "low",
        "sea_chest_valve_open": True,
        "sea_chest_valve_pct": 100,
        "overboard_valve_open": True,
        "overboard_valve_pct": 100,
        "engine_tripped": False,
        "engine_trip_reason": None,
        "aux_valve_open": True,
        "aux_valve_pct": 100,
        "lt3way_mode": "auto",
        "ht3way_mode": "auto",
        "jacket_heater_on": False,
        "mission_hold_seconds": 0,
        "mission_completed": False,
        "mission_failed": False,
        "history": [],
    }
    s.update(isi)
    return s


# ---------------------------------------------------------------- Mode bebas

def buat_sandbox():
    return kondisi_dasar(
        "sandbox",
        sea_water_temp=24,
        telegraph_pct=65, actual_load_pct=65, engine_rpm=82,
        aux_load_pct=45, aux_engine_temp=47.4,
        pumps=buat_pompa(),
        lt3way_cooler_pct=58, ht3way_cooler_pct=52,
        strainer_fouling=8, cooler_fouling=5,
        sw_supply_temp=24, sw_discharge_temp=31.4, sw_flow_total=400, sw_pressure=2.3, strainer_delta_p=0.14,
        lt_supply_temp=36.2, lt_return_temp=44.8, lt_flow_total=360, lt_pressure=2.8,
        ht_inlet_temp=74.5, ht_outlet_temp=81.8, ht_flow_total=240, ht_pressure=3.1,
        lube_oil_temp=48.2, scavenge_air_temp=42.6,
        alarms=[alarm_awal(
            "info", "Sistem ECR",
            "Simulator siap. Kondisi laut normal 24°C pada beban mesin 65% & Aux Engine 45%.", True)],
    )


# ---------------------------------------------------------------- Misi 1

def buat_warmup():
    return kondisi_dasar(
        "warmup",
        sea_water_temp=20,
        overboard_valve_open=False,
        telegraph_pct=0, actual_load_pct=0, engine_rpm=0,
        aux_load_pct=35, aux_engine_temp=42,
        pumps=buat_pompa(sw1={"running": False}, lt1={"running": False}, ht1={"running": False}),
        lt3way_cooler_pct=10, ht3way_cooler_pct=5,
        strainer_fouling=5, cooler_fouling=0,
        sw_supply_temp=20, sw_discharge_temp=20, sw_flow_total=0, sw_pressure=0, strainer_delta_p=0,
        lt_supply_temp=26, lt_return_temp=26, lt_flow_total=0, lt_pressure=0,
        ht_inlet_temp=28, ht_outlet_temp=28, ht_flow_total=0, ht_pressure=0,
        lube_oil_temp=28, scavenge_air_temp=26,
        alarms=[alarm_awal(
            "info", "Perwira Jaga",
            "Persiapan berangkat: sirkulasi air tawar & pemanasan jaket mesin diperlukan.")],
    )


def tujuan_warmup(s):
    sirkulasi = s["ht_flow_total"] > 150 and s["lt_flow_total"] > 200
    panas = s["ht_outlet_temp"] >= 58
    sw_aktif = s["overboard_valve_open"] and s["sw_flow_total"] > 250
    berlayar = (s["actual_load_pct"] >= 70 and 74 <= s["ht_outlet_temp"] <= 87 and not s["engine_tripped"])
    stabil = s["mission_hold_seconds"] >= 12
    return [
        {"id": "circ", "label": "Jalankan pompa sirkulasi HT & LT", "completed": sirkulasi,
         "detail": "Sirkulasi aktif" if sirkulasi else "Nyalakan Pompa HT #1 & LT #1"},
        {"id": "preheat", "label": "Panaskan air jaket HT ≥ 58°C", "completed": panas,
         "detail": f"{s['ht_outlet_temp']:.1f}°C / 58.0°C"},
        {"id": "sw", "label": "Buka katup Overboard & nyalakan Pompa SW", "completed": sw_aktif,
         "detail": f"Aliran SW {s['sw_flow_total']:.0f} m³/h" if sw_aktif else "Katup & pompa SW belum aktif"},
        {"id": "cruise", "label": "Berlayar ≥ 70% beban & stabil 12 detik (74–87°C)", "completed": stabil,
         "detail": (f"Stabilisasi {min(12, s['mission_hold_seconds']):.0f}/12 dtk" if berlayar
                    else f"Beban {s['actual_load_pct']:.0f}% · HT {s['ht_outlet_temp']:.1f}°C")},
    ]


# ---------------------------------------------------------------- Misi 2

def buat_tropical():
    return kondisi_dasar(
        "tropical",
        sea_water_temp=32,
        telegraph_pct=85, actual_load_pct=85, engine_rpm=104,
        aux_load_pct=65, aux_engine_temp=58.5,
        pumps=buat_pompa(),
        lt3way_cooler_pct=92, ht3way_cooler_pct=85,
        strainer_fouling=68, cooler_fouling=52,
        sw_supply_temp=32, sw_discharge_temp=44.5, sw_flow_total=195, sw_pressure=1.4, strainer_delta_p=1.15,
        lt_supply_temp=44.2, lt_return_temp=54.0, lt_flow_total=360, lt_pressure=2.7,
        ht_inlet_temp=81.0, ht_outlet_temp=89.4, ht_flow_total=240, ht_pressure=3.1,
        lube_oil_temp=61.5, scavenge_air_temp=54.2,
        alarms=[
            alarm_awal("warning", "SW Strainer",
                       "Tekanan diferensial filter air laut tinggi (1.15 bar). Segera bersihkan/backwash!"),
            alarm_awal("warning", "Central Cooler",
                       "Efisiensi penukar panas menurun akibat fouling (52%) pada air laut 32°C."),
        ],
    )


def tujuan_tropical(s):
    filter_bersih = s["strainer_fouling"] <= 20
    cooler_bersih = s["cooler_fouling"] <= 20
    dua_pompa = s["pumps"]["sw1"]["running"] and s["pumps"]["sw2"]["running"]
    stabil = s["mission_hold_seconds"] >= 15
    return [
        {"id": "strainer", "label": "Backwash Filter SW (Fouling ≤ 20%)", "completed": filter_bersih,
         "detail": f"Fouling: {s['strainer_fouling']:.0f}%"},
        {"id": "cooler", "label": "Bersihkan pelat Central Cooler (≤ 20%)", "completed": cooler_bersih,
         "detail": f"Kerak: {s['cooler_fouling']:.0f}%"},
        {"id": "parallel", "label": "Aktifkan Pompa SW #1 & #2 paralel", "completed": dua_pompa,
         "detail": f"Aliran {s['sw_flow_total']:.0f} m³/h" if dua_pompa else "Jalankan kedua pompa SW"},
        {"id": "temp", "label": "Pertahankan HT < 87°C & beban ≥ 80% selama 15 detik", "completed": stabil,
         "detail": f"{min(15, s['mission_hold_seconds']):.0f}/15 dtk · HT {s['ht_outlet_temp']:.1f}°C"},
    ]


# ---------------------------------------------------------------- Misi 3

def buat_emergency():
    return kondisi_dasar(
        "emergency",
        sea_water_temp=28,
        telegraph_pct=88, actual_load_pct=88, engine_rpm=108,
        aux_load_pct=60, aux_engine_temp=62.4,
        pumps=buat_pompa(sw1={"running": False, "tripped": True}, sw2={"running": False, "tripped": False}),
        lt3way_mode="manual", lt3way_cooler_pct=25, ht3way_cooler_pct=95,
        strainer_fouling=15, cooler_fouling=12,
        sw_supply_temp=28, sw_discharge_temp=33, sw_flow_total=0, sw_pressure=0.1, strainer_delta_p=0,
        lt_supply_temp=52.8, lt_return_temp=62.5, lt_flow_total=360, lt_pressure=2.8,
        ht_inlet_temp=84.5, ht_outlet_temp=91.6, ht_flow_total=240, ht_pressure=3.1,
        lube_oil_temp=66.8, scavenge_air_temp=58.0,
        alarms=[
            alarm_awal("critical", "SW Pump #1",
                       "TRIP: Beban berlebih motor listrik! Aliran air laut terhenti (0 m³/h)."),
            alarm_awal("warning", "LT 3-Way Valve",
                       "Katup terjebak di mode Manual 25%! Ubah ke Auto atau buka penuh ke Central Cooler."),
        ],
    )


def tujuan_emergency(s):
    sw2_jalan = s["pumps"]["sw2"]["running"] and s["sw_flow_total"] > 250
    katup_benar = s["lt3way_mode"] == "auto" or s["lt3way_cooler_pct"] >= 70
    tidak_trip = not s["engine_tripped"]
    stabil = s["mission_hold_seconds"] >= 15
    return [
        {"id": "standby", "label": "Aktifkan Pompa SW #2 (Standby)", "completed": sw2_jalan,
         "detail": f"Aliran {s['sw_flow_total']:.0f} m³/h" if sw2_jalan else "Pompa SW #2 masih mati"},
        {"id": "valve", "label": "Pulihkan Katup 3-Arah LT (Auto / ≥ 70%)", "completed": katup_benar,
         "detail": "Mode Auto aktif" if s["lt3way_mode"] == "auto" else f"Manual {s['lt3way_cooler_pct']:.0f}%"},
        {"id": "notrip", "label": "Cegah Engine Auto-Shutdown (< 98°C)", "completed": tidak_trip,
         "detail": f"HT {s['ht_outlet_temp']:.1f}°C" if tidak_trip else "MESIN TRIP!"},
        {"id": "recover", "label": "Pulihkan daya ≥ 75% & stabilkan HT < 87°C (15 dtk)", "completed": stabil,
         "detail": f"{min(15, s['mission_hold_seconds']):.0f}/15 dtk · Beban {s['actual_load_pct']:.0f}%"},
    ]


# ---------------------------------------------------------------- Daftar skenario

SCENARIOS = {
    "sandbox": {
        "id": "sandbox",
        "title": "Mode Bebas (Sandbox)",
        "difficulty": "Eksplorasi",
        "briefing": "Kendalikan seluruh sistem pendingin kapal secara bebas. Ubah beban mesin utama & auxiliary "
                    "engine, suhu perairan, pompa, bukaan katup manual, atau uji skenario gangguan.",
        "buat_kondisi": buat_sandbox,
        "cek_tujuan": lambda s: [],
    },
    "warmup": {
        "id": "warmup",
        "title": "Misi 1: Pemanasan & Berangkat Pelabuhan",
        "difficulty": "Dasar",
        "briefing": "Mesin utama dingin (28°C) saat bersandar, sementara Auxiliary Engine memasok listrik pelabuhan "
                    "(35%). Jalankan sirkulasi HT & LT, panaskan jaket ≥ 58°C, buka katup overboard & pompa SW, "
                    "lalu berlayar ≥ 70%.",
        "buat_kondisi": buat_warmup,
        "cek_tujuan": tujuan_warmup,
    },
    "tropical": {
        "id": "tropical",
        "title": "Misi 2: Perairan Tropis & Fouling",
        "difficulty": "Menengah",
        "briefing": "Kapal melintasi perairan tropis 32°C dengan beban mesin 85% & Auxiliary Engine 65%. Filter air "
                    "laut tersumbat kotoran (68%) dan Central Cooler berkerak sehingga suhu HT mulai melonjak "
                    "mendekati batas alarm!",
        "buat_kondisi": buat_tropical,
        "cek_tujuan": tujuan_tropical,
    },
    "emergency": {
        "id": "emergency",
        "title": "Misi 3: Kegagalan Pompa Utama (Darurat)",
        "difficulty": "Tantangan",
        "briefing": "DARURAT! Pompa SW #1 mengalami trip elektrik mendadak pada beban mesin 88%, dan katup 3-arah "
                    "LT terjebak di mode Manual (25% ke cooler). Suhu jaket melesat ke 91°C! Selamatkan mesin "
                    "sebelum auto-shutdown (98°C)!",
        "buat_kondisi": buat_emergency,
        "cek_tujuan": tujuan_emergency,
    },
}
