"""
Fungsi untuk menampilkan hasil simulasi: ringkasan teks, log alarm, daftar misi, dan grafik.
"""

import matplotlib.pyplot as plt

from .scenarios import SCENARIOS

NAMA_POMPA = {
    "sw1": "Pompa SW #1", "sw2": "Pompa SW #2",
    "lt1": "Pompa LT #1", "lt2": "Pompa LT #2",
    "ht1": "Pompa HT #1", "ht2": "Pompa HT #2",
}


def status_pompa(pompa):
    if pompa["tripped"]:
        return "TRIP"
    if not pompa["running"]:
        return "mati"
    return f"jalan ({pompa['valve_pct']:.0f}%)"


def ringkasan(s):
    """Teks ringkasan kondisi kapal saat ini."""
    judul = SCENARIOS[s["scenario_id"]]["title"]
    baris = [
        f"{judul}   |   waktu simulasi {s['elapsed_seconds']:.0f} dtk",
        "-" * 60,
        f"Mesin utama : beban {s['actual_load_pct']:.0f}%  ({s['engine_rpm']} rpm)"
        + (f"   TRIP: {s['engine_trip_reason']}" if s["engine_tripped"] else ""),
        f"Aux engine  : beban {s['aux_load_pct']:.0f}%  suhu {s['aux_engine_temp']:.1f} °C",
        f"Air laut    : {s['sea_water_temp']:.0f} °C masuk, {s['sw_discharge_temp']:.1f} °C keluar, "
        f"{s['sw_flow_total']:.0f} m³/h, {s['sw_pressure']:.1f} bar",
        f"LT          : supply {s['lt_supply_temp']:.1f} °C, return {s['lt_return_temp']:.1f} °C, "
        f"{s['lt_flow_total']:.0f} m³/h",
        f"HT (jaket)  : masuk {s['ht_inlet_temp']:.1f} °C, keluar {s['ht_outlet_temp']:.1f} °C, "
        f"{s['ht_flow_total']:.0f} m³/h",
        f"Lube oil    : {s['lube_oil_temp']:.1f} °C   Scavenge air: {s['scavenge_air_temp']:.1f} °C",
        f"Kotor       : filter SW {s['strainer_fouling']:.0f}% (ΔP {s['strainer_delta_p']:.2f} bar), "
        f"central cooler {s['cooler_fouling']:.0f}%",
        f"Katup 3-arah: LT {s['lt3way_mode']} {s['lt3way_cooler_pct']:.0f}%,  "
        f"HT {s['ht3way_mode']} {s['ht3way_cooler_pct']:.0f}%",
        "Pompa       : " + ", ".join(f"{NAMA_POMPA[k]} {status_pompa(v)}" for k, v in s["pumps"].items()),
    ]
    return "\n".join(baris)


def cetak_alarm(s, jumlah=10):
    """Cetak beberapa alarm terbaru."""
    tanda = {"info": "INFO", "warning": "WARN", "critical": "CRIT"}
    for a in s["alarms"][:jumlah]:
        print(f"[{a['waktu']:6.1f} dtk] {tanda[a['tingkat']]}  {a['sumber']}: {a['pesan']}")


def cetak_tujuan(s):
    """Cetak daftar tujuan misi dan apakah sudah tercapai."""
    daftar = SCENARIOS[s["scenario_id"]]["cek_tujuan"](s)
    for t in daftar:
        centang = "[x]" if t["completed"] else "[ ]"
        print(f"{centang} {t['label']}  ({t['detail']})")
    if s["mission_completed"]:
        print("MISI SELESAI")
    elif s["mission_failed"]:
        print("MISI GAGAL (mesin trip)")


def grafik(s, simpan_ke=None, tampil=True):
    """Gambar tiga grafik: suhu, beban mesin, dan aliran air laut. Return objek figure."""
    r = s["history"]
    fig, (a1, a2, a3) = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    if not r:
        a1.text(0.5, 0.5, "Belum ada data. Jalankan simulasi dulu.", ha="center", transform=a1.transAxes)
    else:
        t = [p["time"] for p in r]
        a1.plot(t, [p["ht_outlet"] for p in r], label="HT keluar jaket", linewidth=2)
        a1.plot(t, [p["lt_supply"] for p in r], label="LT supply")
        a1.plot(t, [p["lube_oil"] for p in r], label="Lube oil")
        a1.plot(t, [p["scavenge_air"] for p in r], label="Scavenge air")
        a1.plot(t, [p["aux_engine"] for p in r], label="Aux engine")
        a1.axhline(98, color="red", linestyle="--", linewidth=1)
        a1.text(t[-1], 98.8, "batas trip HT 98 °C", color="red", fontsize=8, ha="right")
        a1.set_ylabel("Suhu (°C)")
        a1.set_ylim(top=112)
        a1.legend(loc="upper left", ncol=3, fontsize=8)
        a2.plot(t, [p["engine_load"] for p in r], color="tab:orange")
        a2.set_ylabel("Beban mesin (%)")
        a3.plot(t, [p["sw_flow"] for p in r], color="tab:blue")
        a3.set_ylabel("Aliran SW (m³/h)")
    a3.set_xlabel("Waktu simulasi (detik)")
    for a in (a1, a2, a3):
        a.grid(alpha=0.3)
    fig.suptitle(SCENARIOS[s["scenario_id"]]["title"])
    fig.tight_layout()
    if simpan_ke:
        fig.savefig(simpan_ke, dpi=130)
    if tampil:
        plt.show()
    return fig
