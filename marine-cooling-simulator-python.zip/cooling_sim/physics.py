"""
Mesin fisika simulator sistem pendingin kapal.

Ini terjemahan dari src/engine/physics.ts pada versi web (React).
Setiap kali fungsi langkah_simulasi() dipanggil, kondisi kapal maju sebesar dt detik.
"""

import math


def batasi(nilai, kecil, besar):
    """Jaga supaya nilai tidak keluar dari rentang kecil..besar."""
    return max(kecil, min(besar, nilai))


def mendekati(sekarang, target, laju):
    """Geser nilai sekarang menuju target. Makin besar laju, makin cepat."""
    return sekarang + (target - sekarang) * batasi(laju, 0, 1)


def bulatkan(x):
    """Pembulatan biasa (0,5 naik). round() bawaan Python membulatkan ke genap."""
    return int(math.floor(x + 0.5))


def tambah_alarm_jika_baru(alarms, waktu, tingkat, sumber, pesan):
    """
    Tambah alarm ke daftar (yang terbaru ditaruh paling depan).
    Alarm dengan sumber dan tingkat yang sama diabaikan kalau baru muncul < 20 detik lalu.
    """
    for a in alarms:
        if a["sumber"] == sumber and a["tingkat"] == tingkat and waktu - a["waktu"] < 20:
            return alarms

    baru = {
        "waktu": waktu,
        "tingkat": tingkat,  # 'info', 'warning', atau 'critical'
        "sumber": sumber,
        "pesan": pesan,
        "acknowledged": False,
    }
    return ([baru] + alarms)[:40]


def faktor_katup(pompa):
    """Seberapa besar aliran yang lewat pompa ini (0 sampai 1). 0 kalau mati/trip/katup tutup."""
    if pompa["running"] and not pompa["tripped"] and pompa["valve_open"] and pompa["valve_pct"] > 0:
        return (pompa["valve_pct"] / 100) ** 0.78
    return 0.0


def motor_hidup(pompa):
    return pompa["running"] and not pompa["tripped"]


def gabung_pompa(f1, f2, faktor_kedua):
    """
    Dua pompa paralel tidak menghasilkan aliran dua kali lipat.
    Kelebihan di atas 1.0 hanya dihitung sebagian (faktor_kedua).
    """
    total = f1 + f2
    if total > 1.0:
        return 1.0 + (total - 1.0) * faktor_kedua
    return total


# Batas jumlah titik riwayat yang disimpan (cukup untuk sekitar 25 menit waktu simulasi)
MAKS_RIWAYAT = 2000


def langkah_simulasi(s, dt_detik):
    """
    Majukan simulasi sebesar dt_detik (dikali kecepatan simulasi).
    s adalah dictionary kondisi kapal dari scenarios.py. Isinya diubah langsung (tidak dikembalikan salinan).
    """
    if not s["running"]:
        return s

    dt = dt_detik * s["speed_multiplier"]
    waktu = s["elapsed_seconds"] + dt

    p = s["pumps"]

    # 1. Beban dan putaran mesin utama
    target_load = 0 if s["engine_tripped"] else s["telegraph_pct"]
    actual_load_pct = mendekati(s["actual_load_pct"], target_load, dt * 0.45)
    engine_rpm = bulatkan(22 + (actual_load_pct / 100) * 98) if actual_load_pct > 1 else 0

    # 2. Hidrolik air laut (sea chest, overboard, katup tiap pompa)
    sw1_active = motor_hidup(p["sw1"]) and p["sw1"]["valve_open"] and p["sw1"]["valve_pct"] > 0
    sw2_active = motor_hidup(p["sw2"]) and p["sw2"]["valve_open"] and p["sw2"]["valve_pct"] > 0

    sw1_valve_factor = faktor_katup(p["sw1"])
    sw2_valve_factor = faktor_katup(p["sw2"])
    sw_combined = gabung_pompa(sw1_valve_factor, sw2_valve_factor, 0.62)

    sea_chest_valve_factor = (s["sea_chest_valve_pct"] / 100) ** 0.75 if s["sea_chest_valve_open"] else 0
    overboard_valve_factor = (s["overboard_valve_pct"] / 100) ** 0.75 if s["overboard_valve_open"] else 0
    sw_path_factor = min(sea_chest_valve_factor, overboard_valve_factor)

    strainer_factor = batasi(1 - (s["strainer_fouling"] / 100) * 0.72, 0.18, 1)
    sea_chest_factor = 0.96 if s["sea_chest_mode"] == "high" else 1.0
    sw_target_flow = 420 * sw_combined * sw_path_factor * strainer_factor * sea_chest_factor
    sw_flow_total = mendekati(s["sw_flow_total"], sw_target_flow, dt * 1.6)

    sw_motor_count = (1 if motor_hidup(p["sw1"]) else 0) + (1 if motor_hidup(p["sw2"]) else 0)
    if sw_motor_count == 0:
        sw_target_pressure = 0.05
    elif (not s["sea_chest_valve_open"]) or s["sea_chest_valve_pct"] == 0:
        sw_target_pressure = 0.15  # hisap kering / kavitasi
    elif s["overboard_valve_open"] and s["overboard_valve_pct"] > 5 and (sw1_active or sw2_active):
        sw_target_pressure = (1.7 + sw_combined * 0.65) * (0.45 + 0.55 * strainer_factor)
    else:
        sw_target_pressure = 3.6  # tekanan buntu (deadhead), discharge atau overboard tertutup
    sw_pressure = mendekati(s["sw_pressure"], sw_target_pressure, dt * 1.8)
    if sw_flow_total > 10:
        strainer_delta_p = batasi((s["strainer_fouling"] / 100) * 1.45 * (sw_flow_total / 320), 0.05, 1.8)
    else:
        strainer_delta_p = 0

    # 3. Hidrolik air tawar LT
    lt1_factor = faktor_katup(p["lt1"])
    lt2_factor = faktor_katup(p["lt2"])
    lt_combined = gabung_pompa(lt1_factor, lt2_factor, 0.56)
    lt_active_count = (1 if lt1_factor > 0 else 0) + (1 if lt2_factor > 0 else 0)
    lt_target_flow = 360 * lt_combined
    lt_flow_total = mendekati(s["lt_flow_total"], lt_target_flow, dt * 1.8)
    if motor_hidup(p["lt1"]) or motor_hidup(p["lt2"]):
        lt_target_pressure = 3.4 if lt_active_count == 0 else 2.3 + lt_combined * 0.5
    else:
        lt_target_pressure = 0.2
    lt_pressure = mendekati(s["lt_pressure"], lt_target_pressure, dt * 1.8)

    # 4. Hidrolik air tawar HT
    ht1_factor = faktor_katup(p["ht1"])
    ht2_factor = faktor_katup(p["ht2"])
    ht_combined = gabung_pompa(ht1_factor, ht2_factor, 0.54)
    ht_active_count = (1 if ht1_factor > 0 else 0) + (1 if ht2_factor > 0 else 0)
    ht_target_flow = 240 * ht_combined
    ht_flow_total = mendekati(s["ht_flow_total"], ht_target_flow, dt * 1.8)
    if motor_hidup(p["ht1"]) or motor_hidup(p["ht2"]):
        ht_target_pressure = 3.6 if ht_active_count == 0 else 2.5 + ht_combined * 0.6
    else:
        ht_target_pressure = 0.4
    ht_pressure = mendekati(s["ht_pressure"], ht_target_pressure, dt * 1.8)

    # Isi aliran dan tekanan tiap pompa (tampilan)
    def perbarui_pompa(id_pompa, faktor, faktor_total, aliran_total, tekanan_sistem):
        pp = p[id_pompa]
        hidup = motor_hidup(pp)
        pp["flow_rate"] = (aliran_total * faktor) / faktor_total if (hidup and faktor_total > 0.01) else 0
        pp["pressure"] = tekanan_sistem if hidup else 0

    perbarui_pompa("sw1", sw1_valve_factor, sw1_valve_factor + sw2_valve_factor, sw_flow_total, sw_pressure)
    perbarui_pompa("sw2", sw2_valve_factor, sw1_valve_factor + sw2_valve_factor, sw_flow_total, sw_pressure)
    perbarui_pompa("lt1", lt1_factor, lt1_factor + lt2_factor, lt_flow_total, lt_pressure)
    perbarui_pompa("lt2", lt2_factor, lt1_factor + lt2_factor, lt_flow_total, lt_pressure)
    perbarui_pompa("ht1", ht1_factor, ht1_factor + ht2_factor, ht_flow_total, ht_pressure)
    perbarui_pompa("ht2", ht2_factor, ht1_factor + ht2_factor, ht_flow_total, ht_pressure)

    # 5. Filter pelan-pelan kotor kalau air laut mengalir (kecuali skenario warmup)
    strainer_fouling = s["strainer_fouling"]
    if sw_flow_total > 50 and s["scenario_id"] != "warmup":
        strainer_fouling = batasi(strainer_fouling + dt * 0.015, 0, 95)

    # 6. Pengatur katup 3-arah
    lt3way_cooler_pct = s["lt3way_cooler_pct"]
    if s["lt3way_mode"] == "auto":
        lt_error = s["lt_supply_temp"] - 36.0
        target_pct = batasi(50 + lt_error * 9.5, 5, 100)
        lt3way_cooler_pct = mendekati(lt3way_cooler_pct, target_pct, dt * 0.65)

    ht3way_cooler_pct = s["ht3way_cooler_pct"]
    if s["ht3way_mode"] == "auto":
        ht_error = s["ht_outlet_temp"] - 82.0
        target_pct = batasi(45 + ht_error * 11, 0, 100)
        ht3way_cooler_pct = mendekati(ht3way_cooler_pct, target_pct, dt * 0.7)

    # 7. Neraca energi (panas)
    load_factor = (actual_load_pct / 100) ** 1.25
    aux_load_factor = (s["aux_load_pct"] / 100) ** 1.18
    suhu_ruang = 31

    # Panas masuk dari mesin utama dan auxiliary engine
    jacket_heat_input = 4.0 + load_factor * 105.0 + (24.0 if s["jacket_heater_on"] else 0)
    lube_oil_heat_input = 2.0 + load_factor * 44.0
    scavenge_heat_input = 1.5 + load_factor * 52.0
    aux_heat_input = 2.5 + aux_load_factor * 36.0

    # Pemindahan panas HT -> LT
    ht_cooling_flow_factor = batasi(ht_flow_total / 240, 0.05, 1.35) * (ht3way_cooler_pct / 100)
    lt_ht_exchanger_factor = batasi(lt_flow_total / 360, 0.04, 1.3)
    ht_to_lt_coeff = min(ht_cooling_flow_factor, lt_ht_exchanger_factor) * 1.75
    ht_delta_t = max(0, s["ht_outlet_temp"] - s["lt_return_temp"])
    ht_heat_rejected = ht_delta_t * ht_to_lt_coeff

    ht_thermal_mass = 28.0 if ht_flow_total > 40 else 9.5
    ht_ambient_loss = (s["ht_outlet_temp"] - suhu_ruang) * 0.08
    d_ht_outlet = ((jacket_heat_input - ht_heat_rejected - ht_ambient_loss) / ht_thermal_mass) * dt
    ht_outlet_temp = batasi(s["ht_outlet_temp"] + d_ht_outlet, s["sea_water_temp"], 118)

    if ht_flow_total > 30:
        ht_inlet_target = batasi(
            ht_outlet_temp - (jacket_heat_input / max(80, ht_flow_total)) * 16,
            s["lt_supply_temp"],
            ht_outlet_temp,
        )
    else:
        ht_inlet_target = ht_outlet_temp - 1.5
    ht_inlet_temp = mendekati(s["ht_inlet_temp"], ht_inlet_target, dt * 0.85)

    # Lube oil, scavenge air, dan auxiliary engine didinginkan oleh LT
    lt_cooling_flow_norm = batasi(lt_flow_total / 360, 0.03, 1.35)
    lo_cooling = max(0, s["lube_oil_temp"] - s["lt_supply_temp"]) * lt_cooling_flow_norm * 2.1
    lo_ambient = (s["lube_oil_temp"] - suhu_ruang) * 0.05
    lube_oil_temp = batasi(
        s["lube_oil_temp"] + ((lube_oil_heat_input - lo_cooling - lo_ambient) / 18) * dt, 24, 105
    )

    scav_cooling = max(0, s["scavenge_air_temp"] - s["lt_supply_temp"]) * lt_cooling_flow_norm * 2.4
    scav_ambient = (s["scavenge_air_temp"] - suhu_ruang) * 0.06
    scavenge_air_temp = batasi(
        s["scavenge_air_temp"] + ((scavenge_heat_input - scav_cooling - scav_ambient) / 14) * dt, 24, 105
    )

    aux_valve_factor = (s["aux_valve_pct"] / 100) ** 0.75 if s["aux_valve_open"] else 0
    aux_cooling = (
        max(0, s["aux_engine_temp"] - s["lt_supply_temp"]) * lt_cooling_flow_norm * aux_valve_factor * 2.25
    )
    aux_ambient = (s["aux_engine_temp"] - suhu_ruang) * 0.06
    aux_engine_temp = batasi(
        s["aux_engine_temp"] + ((aux_heat_input - aux_cooling - aux_ambient) / 15) * dt, 24, 105
    )

    # Suhu LT return mengumpulkan panas dari lube oil, scavenge air, aux engine, dan penukar HT/LT
    total_lt_heat_load = ht_heat_rejected + lo_cooling * 0.65 + scav_cooling * 0.65 + aux_cooling * 0.7
    if lt_flow_total > 30:
        lt_return_target = batasi(
            s["lt_supply_temp"] + (total_lt_heat_load / max(120, lt_flow_total)) * 28,
            s["lt_supply_temp"],
            96,
        )
    else:
        lt_return_target = s["lt_return_temp"] + (total_lt_heat_load / 40) * dt
    lt_return_temp = mendekati(s["lt_return_temp"], lt_return_target, dt * 0.9)

    # Central cooler: LT <-> air laut
    cooler_efficiency = batasi(1 - (s["cooler_fouling"] / 100) * 0.65, 0.25, 1.0)
    sw_effectiveness = batasi(sw_flow_total / 380, 0, 1.35) * cooler_efficiency
    lt_through_cooler = (lt3way_cooler_pct / 100) * lt_cooling_flow_norm
    central_coeff = min(sw_effectiveness, lt_through_cooler) * 2.75

    central_delta_t = max(0, lt_return_temp - s["sea_water_temp"])
    heat_rejected_to_sea = central_delta_t * central_coeff

    lt_thermal_mass = 22.0 if lt_flow_total > 40 else 12.0
    lt_net_heat = total_lt_heat_load - heat_rejected_to_sea - (s["lt_supply_temp"] - suhu_ruang) * 0.06
    lt_supply_temp = batasi(
        s["lt_supply_temp"] + (lt_net_heat / lt_thermal_mass) * dt, s["sea_water_temp"], 92
    )

    # Suhu air laut
    sw_supply_temp = s["sea_water_temp"]
    if sw_flow_total > 20:
        sw_discharge_target = batasi(
            sw_supply_temp + (heat_rejected_to_sea / max(100, sw_flow_total)) * 34, sw_supply_temp, 68
        )
    else:
        sw_discharge_target = sw_supply_temp
    sw_discharge_temp = mendekati(s["sw_discharge_temp"], sw_discharge_target, dt * 0.9)

    # 8. Alarm dan trip pengaman mesin
    alarms = s["alarms"]
    engine_tripped = s["engine_tripped"]
    engine_trip_reason = s["engine_trip_reason"]

    if actual_load_pct > 40 and ht_outlet_temp < 50:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "warning", "Main Engine",
            f"Beban tinggi ({actual_load_pct:.0f}%) saat mesin masih dingin ({ht_outlet_temp:.1f}°C)! Risiko thermal shock.",
        )
    if aux_engine_temp >= 78:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "warning", "Auxiliary Engine",
            f"Suhu Auxiliary Engine tinggi ({aux_engine_temp:.1f}°C)! Periksa katup pendingin Aux ({s['aux_valve_pct']:.0f}%) atau aliran LT.",
        )
    if 88 <= ht_outlet_temp < 95:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "warning", "HT Jacket Water",
            f"Suhu air jaket tinggi ({ht_outlet_temp:.1f}°C). Periksa aliran SW, fouling cooler, atau turunkan beban.",
        )
    if ht_outlet_temp >= 95 and not engine_tripped:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "critical", "HT Jacket Water",
            f"KRITIS: Suhu jaket mencapai {ht_outlet_temp:.1f}°C! Auto-shutdown aktif pada 98°C.",
        )
    if ht_outlet_temp >= 98 and not engine_tripped:
        engine_tripped = True
        engine_trip_reason = "Overheat Air Jaket HT (≥ 98°C)"
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "critical", "Safety Shutdown",
            "AUTO-TRIP MESIN UTAMA: Suhu HT mencapai 98°C untuk mencegah kerusakan silinder!",
        )
    if lube_oil_temp >= 78 and not engine_tripped:
        engine_tripped = True
        engine_trip_reason = "Overheat Oli Pelumas (≥ 78°C)"
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "critical", "Safety Shutdown",
            "AUTO-TRIP MESIN UTAMA: Suhu Lube Oil melebihi batas aman (78°C)!",
        )
    if strainer_delta_p >= 0.95:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "warning", "SW Strainer",
            f"Filter air laut tersumbat (ΔP {strainer_delta_p:.2f} bar). Lakukan backwash.",
        )
    if (not s["overboard_valve_open"] or s["overboard_valve_pct"] < 10) and sw_motor_count > 0:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "warning", "Overboard Valve",
            "Pompa SW menyala tetapi katup Overboard tertutup/tercekik! Aliran pendinginan terhenti.",
        )
    if (not s["sea_chest_valve_open"] or s["sea_chest_valve_pct"] < 10) and sw_motor_count > 0:
        alarms = tambah_alarm_jika_baru(
            alarms, waktu, "warning", "Sea Chest Valve",
            "Katup hisap Sea Chest tertutup saat pompa SW berjalan! Risiko kavitasi pompa.",
        )

    # 9. Penghitung waktu misi dan pengecekan selesai
    mission_hold = s["mission_hold_seconds"]
    mission_completed = s["mission_completed"]
    mission_failed = s["mission_failed"]

    if s["scenario_id"] == "warmup":
        ok = (
            actual_load_pct >= 70
            and 74 <= ht_outlet_temp <= 87
            and s["overboard_valve_open"]
            and sw_flow_total > 250
            and not engine_tripped
        )
        mission_hold = mission_hold + dt if ok else max(0, mission_hold - dt * 0.5)
        if mission_hold >= 12:
            mission_completed = True
    elif s["scenario_id"] == "tropical":
        ok = (
            s["strainer_fouling"] <= 20
            and s["cooler_fouling"] <= 20
            and p["sw1"]["running"]
            and p["sw2"]["running"]
            and actual_load_pct >= 80
            and ht_outlet_temp < 87
            and not engine_tripped
        )
        mission_hold = mission_hold + dt if ok else max(0, mission_hold - dt * 0.5)
        if mission_hold >= 15:
            mission_completed = True
    elif s["scenario_id"] == "emergency":
        if engine_tripped:
            mission_failed = True
        ok = (
            p["sw2"]["running"]
            and sw_flow_total > 250
            and (s["lt3way_mode"] == "auto" or s["lt3way_cooler_pct"] >= 70)
            and actual_load_pct >= 75
            and ht_outlet_temp < 87
            and not engine_tripped
        )
        mission_hold = mission_hold + dt if ok else max(0, mission_hold - dt * 0.5)
        if mission_hold >= 15 and not mission_failed:
            mission_completed = True

    # 10. Catat riwayat (sekitar tiap 0,8 detik waktu simulasi)
    riwayat = s["history"]
    waktu_terakhir = riwayat[-1]["time"] if riwayat else -1
    if waktu - waktu_terakhir >= 0.8:
        riwayat.append({
            "time": round(waktu, 1),
            "ht_outlet": round(ht_outlet_temp, 2),
            "lt_supply": round(lt_supply_temp, 2),
            "lube_oil": round(lube_oil_temp, 2),
            "scavenge_air": round(scavenge_air_temp, 2),
            "aux_engine": round(aux_engine_temp, 2),
            "engine_load": round(actual_load_pct, 1),
            "sw_flow": round(sw_flow_total),
        })
        if len(riwayat) > MAKS_RIWAYAT:
            del riwayat[0]

    # Simpan hasil perhitungan ke kondisi kapal
    s.update({
        "elapsed_seconds": waktu,
        "actual_load_pct": actual_load_pct,
        "engine_rpm": engine_rpm,
        "engine_tripped": engine_tripped,
        "engine_trip_reason": engine_trip_reason,
        "aux_engine_temp": aux_engine_temp,
        "lt3way_cooler_pct": lt3way_cooler_pct,
        "ht3way_cooler_pct": ht3way_cooler_pct,
        "strainer_fouling": strainer_fouling,
        "sw_supply_temp": sw_supply_temp,
        "sw_discharge_temp": sw_discharge_temp,
        "sw_flow_total": sw_flow_total,
        "sw_pressure": sw_pressure,
        "strainer_delta_p": strainer_delta_p,
        "lt_supply_temp": lt_supply_temp,
        "lt_return_temp": lt_return_temp,
        "lt_flow_total": lt_flow_total,
        "lt_pressure": lt_pressure,
        "ht_inlet_temp": ht_inlet_temp,
        "ht_outlet_temp": ht_outlet_temp,
        "ht_flow_total": ht_flow_total,
        "ht_pressure": ht_pressure,
        "lube_oil_temp": lube_oil_temp,
        "scavenge_air_temp": scavenge_air_temp,
        "mission_hold_seconds": mission_hold,
        "mission_completed": mission_completed,
        "mission_failed": mission_failed,
        "alarms": alarms,
    })
    return s
