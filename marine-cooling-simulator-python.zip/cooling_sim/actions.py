"""
Aksi operator: menyalakan pompa, backwash filter, reset trip, memasukkan gangguan, dan sebagainya.
Terjemahan dari fungsi handle... di src/App.tsx pada versi web.

Semua fungsi mengubah kondisi kapal s secara langsung.
"""


def catat(s, tingkat, sumber, pesan, acknowledged=True):
    """Tambahkan satu baris ke log alarm (maksimal 40 baris, yang terbaru di depan)."""
    s["alarms"] = ([{
        "waktu": s["elapsed_seconds"],
        "tingkat": tingkat,
        "sumber": sumber,
        "pesan": pesan,
        "acknowledged": acknowledged,
    }] + s["alarms"])[:40]


# ---------------------------------------------------------------- Pompa dan katup

def toggle_pompa(s, id_pompa):
    """Nyalakan/matikan pompa. Pompa yang sedang trip tidak bisa dinyalakan (reset dulu)."""
    pompa = s["pumps"][id_pompa]
    if pompa["tripped"]:
        return
    pompa["running"] = not pompa["running"]


def reset_trip_pompa(s, id_pompa):
    pompa = s["pumps"][id_pompa]
    pompa["tripped"] = False
    pompa["running"] = True


def toggle_katup_pompa(s, id_pompa):
    pompa = s["pumps"][id_pompa]
    pompa["valve_open"] = not pompa["valve_open"]
    if pompa["valve_open"] and pompa["valve_pct"] == 0:
        pompa["valve_pct"] = 100


def atur_katup_pompa(s, id_pompa, persen):
    """Atur bukaan katup discharge pompa (0 sampai 100)."""
    pompa = s["pumps"][id_pompa]
    pompa["valve_open"] = persen > 0
    pompa["valve_pct"] = persen


def toggle_sea_chest_valve(s):
    s["sea_chest_valve_open"] = not s["sea_chest_valve_open"]
    if s["sea_chest_valve_open"] and s["sea_chest_valve_pct"] == 0:
        s["sea_chest_valve_pct"] = 100


def atur_sea_chest_valve(s, persen):
    s["sea_chest_valve_open"] = persen > 0
    s["sea_chest_valve_pct"] = persen


def toggle_sea_chest_mode(s):
    """Ganti sea chest antara low (bawah) dan high (atas)."""
    s["sea_chest_mode"] = "high" if s["sea_chest_mode"] == "low" else "low"


def toggle_overboard(s):
    s["overboard_valve_open"] = not s["overboard_valve_open"]
    if s["overboard_valve_open"] and s["overboard_valve_pct"] == 0:
        s["overboard_valve_pct"] = 100


def atur_overboard(s, persen):
    s["overboard_valve_open"] = persen > 0
    s["overboard_valve_pct"] = persen


def mode_3way(s, loop, mode):
    """loop: 'lt' atau 'ht'. mode: 'auto' atau 'manual'."""
    s[f"{loop}3way_mode"] = mode


def atur_3way(s, loop, persen):
    """Bukaan katup 3-arah ke cooler (hanya berpengaruh kalau mode manual)."""
    s[f"{loop}3way_cooler_pct"] = persen


def toggle_pemanas_jaket(s):
    s["jacket_heater_on"] = not s["jacket_heater_on"]


# ---------------------------------------------------------------- Perawatan

def backwash_strainer(s):
    s["strainer_fouling"] = 4
    catat(s, "info", "SW Strainer", "Backwash selesai. Filter air laut kembali bersih (4%).")


def bersihkan_cooler(s):
    s["cooler_fouling"] = 3
    catat(s, "info", "Central Cooler", "Pembersihan pelat titanium selesai. Efisiensi penukar panas pulih (97%).")


def reset_trip_mesin(s):
    """Reset safety shutdown. Hanya bisa kalau suhu jaket HT sudah di bawah 92°C. Return True kalau berhasil."""
    if s["ht_outlet_temp"] >= 92:
        return False
    s["engine_tripped"] = False
    s["engine_trip_reason"] = None
    s["telegraph_pct"] = min(s["telegraph_pct"], 35)
    catat(s, "info", "Main Engine", "Safety shutdown direset. Silakan naikkan beban mesin secara bertahap.")
    return True


def acknowledge_semua(s):
    for a in s["alarms"]:
        a["acknowledged"] = True


# ---------------------------------------------------------------- Gangguan untuk uji coba

def injeksi_gangguan(s, jenis):
    """jenis: 'sw1_trip', 'strainer_clog', 'cooler_foul', atau 'lt_valve_stuck'."""
    if jenis == "sw1_trip":
        s["pumps"]["sw1"]["running"] = False
        s["pumps"]["sw1"]["tripped"] = True
        catat(s, "critical", "SW Pump #1", "GANGGUAN DIUJI: Pompa SW #1 mengalami trip elektrik!", False)
    elif jenis == "strainer_clog":
        s["strainer_fouling"] = 74
        catat(s, "warning", "SW Strainer", "GANGGUAN DIUJI: Sampah laut menyumbat Filter SW (74%).", False)
    elif jenis == "cooler_foul":
        s["cooler_fouling"] = 60
        catat(s, "warning", "Central Cooler", "GANGGUAN DIUJI: Terbentuk kerak tebal pada Central Cooler (60%).", False)
    elif jenis == "lt_valve_stuck":
        s["lt3way_mode"] = "manual"
        s["lt3way_cooler_pct"] = 20
        catat(s, "warning", "LT 3-Way Valve",
              "GANGGUAN DIUJI: Katup 3-Arah LT beralih ke Manual (20% ke cooler).", False)
    else:
        raise ValueError(f"Jenis gangguan tidak dikenal: {jenis}")
