# Marine Cooling Simulator (versi Python)

Simulator sistem pendingin kapal: sirkuit air laut (SW), air tawar suhu rendah (LT), dan air tawar suhu tinggi (HT) untuk mesin utama dan auxiliary engine. Kondisi bisa diatur lewat pompa, katup 3-arah, beban mesin, dan suhu laut, lalu dilihat hasilnya sebagai angka dan grafik.

Proyek ini diterjemahkan dari aplikasi web (React + TypeScript, dibuat di Google AI Studio) ke Python, supaya bisa dijalankan di VS Code atau Google Colab.

![Grafik Misi 1](docs/misi1.png)

## Isi folder

| File | Fungsi |
|---|---|
| `cooling_sim/physics.py` | Mesin fisika: aliran, tekanan, neraca panas, alarm, dan trip mesin |
| `cooling_sim/scenarios.py` | Kondisi awal dan tujuan tiap skenario |
| `cooling_sim/actions.py` | Aksi operator: nyalakan pompa, backwash, reset trip, beri gangguan |
| `cooling_sim/tampilan.py` | Ringkasan teks dan grafik |
| `run_simulasi.py` | Contoh dijalankan dari VS Code / terminal |
| `Marine_Cooling_Simulator.ipynb` | Versi Google Colab, lengkap dengan panel tombol dan slider |

## Menjalankan di Google Colab

1. Upload file `Marine_Cooling_Simulator.ipynb` ke [colab.research.google.com](https://colab.research.google.com), atau setelah proyek ada di GitHub, buka lewat badge ini (ganti `USERNAME` dan `NAMA-REPO`):

   [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USERNAME/NAMA-REPO/blob/main/Marine_Cooling_Simulator.ipynb)

2. Pilih *Runtime > Run all*.
3. Di sel paling bawah muncul panel kontrol. Tekan tombol Play untuk menjalankan waktu, atau **+10 detik** untuk maju cepat.

Notebook ini berdiri sendiri (kode mesin simulasinya sudah ada di dalam sel), jadi tidak perlu meng-upload folder `cooling_sim`.

## Menjalankan di VS Code

Butuh Python 3.9 atau lebih baru.

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate     # macOS / Linux
pip install -r requirements.txt

python run_simulasi.py misi1      # Misi 1 diselesaikan dengan urutan langkah yang benar
python run_simulasi.py darurat    # Misi 3: tanpa tindakan vs ditangani
python run_simulasi.py bebas      # mode bebas
```

Grafik dan data CSV tersimpan di folder `hasil/`. Tambahkan `--tampil` kalau ingin jendela grafik muncul.

## Memakai simulator lewat kode

```python
from cooling_sim import SCENARIOS, langkah_simulasi, actions as aksi
from cooling_sim.tampilan import ringkasan, grafik

s = SCENARIOS["tropical"]["buat_kondisi"]()   # sandbox, warmup, tropical, atau emergency

aksi.backwash_strainer(s)
aksi.toggle_pompa(s, "sw2")
s["telegraph_pct"] = 70                       # beban mesin 70%

for _ in range(400):                          # 400 langkah x 0,25 detik = 100 detik
    langkah_simulasi(s, 0.25)

print(ringkasan(s))
grafik(s)
```

Semua kondisi kapal ada di satu dictionary `s`. Nama kuncinya sama dengan versi web, hanya ditulis `snake_case` (misalnya `htOutletTemp` menjadi `ht_outlet_temp`).

## Skenario

| Kode | Skenario | Tingkat |
|---|---|---|
| `sandbox` | Mode bebas | Eksplorasi |
| `warmup` | Misi 1: Pemanasan dan berangkat dari pelabuhan | Dasar |
| `tropical` | Misi 2: Perairan tropis dan fouling | Menengah |
| `emergency` | Misi 3: Kegagalan pompa utama | Tantangan |

## Catatan

- **Hasil hitungan sama dengan versi web.** Mesin Python ini dibandingkan langsung dengan kode TypeScript aslinya pada 8 uji (keempat skenario, dengan dan tanpa tindakan operator). Selisih terbesarnya sekitar 1e-14, jadi hanya pembulatan komputer.
- **Yang tidak ikut dibawa:** tampilan diagram P&ID, bunyi alarm, dan tab panduan. Riwayat grafik disimpan sampai 2000 titik (versi web hanya 90).
- **Model fisikanya cukup panas.** Di mode bebas dengan pengaturan awal, suhu jaket HT naik pelan-pelan ke sekitar 97 °C (batas trip 98 °C). Pada pengujian dengan semua pompa menyala, kedua katup 3-arah dibuka penuh, serta filter dan cooler bersih, suhu HT stabil sekitar 98 °C untuk syarat Misi 2 (beban 80%, laut 32 °C) dan sekitar 91,5 °C untuk Misi 3 (beban 75%, laut 28 °C). Syarat selesai kedua misi itu adalah HT di bawah 87 °C, jadi keduanya tampaknya tidak bisa diselesaikan. Misi 1 bisa selesai (lihat `python run_simulasi.py misi1`). Perilaku ini sudah ada di aplikasi web aslinya dan sengaja tidak diubah. Kalau mau, ambang beban atau suhu bisa disesuaikan di `cooling_sim/scenarios.py` dan `physics.py`.

## Upload ke GitHub

```bash
git init
git add .
git commit -m "Marine Cooling Simulator versi Python"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```

Buat dulu repository kosong di github.com (tanpa README), lalu ganti `USERNAME` dan `NAMA-REPO` di atas dan di badge Colab.
