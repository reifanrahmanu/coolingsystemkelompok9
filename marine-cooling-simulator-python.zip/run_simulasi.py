"""
Contoh menjalankan simulator dari VS Code atau terminal.

    python run_simulasi.py misi1      # Misi 1 diselesaikan dengan urutan langkah yang benar
    python run_simulasi.py darurat    # Misi 3: bandingkan tanpa tindakan vs ditangani
    python run_simulasi.py bebas      # Mode bebas, beban dinaikkan di tengah jalan

Tambahkan --tampil kalau ingin jendela grafik muncul. Tanpa itu, grafik hanya disimpan ke folder hasil/.
"""

import argparse
import csv
import os

import matplotlib.pyplot as plt

from cooling_sim import SCENARIOS, langkah_simulasi
from cooling_sim import actions as aksi
from cooling_sim.tampilan import ringkasan, cetak_alarm, cetak_tujuan, grafik

DT = 0.25          # tiap langkah = 0,25 detik waktu simulasi (sama seperti versi web)
FOLDER_HASIL = "hasil"


def jalankan(s, detik, tiap_langkah=None, berhenti_jika_selesai=True):
    """
    Jalankan simulasi sebanyak 'detik' detik.
    tiap_langkah(s, t) boleh diisi fungsi yang dipanggil sebelum setiap langkah (untuk mengatur pompa, katup, dll).
    """
    jumlah = int(detik / DT)
    for i in range(1, jumlah + 1):
        if tiap_langkah:
            tiap_langkah(s, i * DT)
        langkah_simulasi(s, DT)
        if berhenti_jika_selesai and (s["mission_completed"] or s["engine_tripped"]):
            break
    return s


def simpan_csv(s, nama_file):
    if not s["history"]:
        return
    with open(nama_file, "w", newline="", encoding="utf-8") as f:
        penulis = csv.DictWriter(f, fieldnames=list(s["history"][0].keys()))
        penulis.writeheader()
        penulis.writerows(s["history"])


def laporan(s, nama):
    print()
    print(ringkasan(s))
    print()
    cetak_tujuan(s)
    print()
    cetak_alarm(s, 6)
    simpan_csv(s, os.path.join(FOLDER_HASIL, f"{nama}.csv"))


# ---------------------------------------------------------------- Demo 1: Misi 1

def demo_misi1():
    s = SCENARIOS["warmup"]["buat_kondisi"]()

    # Langkah awal: nyalakan sirkulasi, buka overboard, hidupkan pemanas jaket
    for pompa in ("sw1", "lt1", "ht1"):
        aksi.toggle_pompa(s, pompa)
    aksi.toggle_overboard(s)
    aksi.toggle_pemanas_jaket(s)
    sudah_panas = False

    def tiap(s, t):
        nonlocal sudah_panas
        # Setelah jaket mencapai 60 °C: matikan pemanas, naikkan beban, buka penuh katup 3-arah
        if not sudah_panas and s["ht_outlet_temp"] >= 60:
            sudah_panas = True
            s["jacket_heater_on"] = False
            s["telegraph_pct"] = 72
            for loop in ("lt", "ht"):
                aksi.mode_3way(s, loop, "manual")
                aksi.atur_3way(s, loop, 100)

    jalankan(s, 300, tiap)
    laporan(s, "misi1")
    grafik(s, os.path.join(FOLDER_HASIL, "misi1.png"), tampil=ARGS.tampil)


# ---------------------------------------------------------------- Demo 2: Misi 3

def demo_darurat():
    # Percobaan A: tidak melakukan apa-apa
    a = SCENARIOS["emergency"]["buat_kondisi"]()
    jalankan(a, 200, berhenti_jika_selesai=False)

    # Percobaan B: nyalakan SW #2 dan pompa cadangan lain, katup 3-arah dibuka penuh, beban diturunkan ke 50%
    b = SCENARIOS["emergency"]["buat_kondisi"]()
    aksi.toggle_pompa(b, "sw2")
    aksi.toggle_pompa(b, "lt2")
    aksi.toggle_pompa(b, "ht2")
    for loop in ("lt", "ht"):
        aksi.mode_3way(b, loop, "manual")
        aksi.atur_3way(b, loop, 100)
    b["telegraph_pct"] = 50
    jalankan(b, 200, berhenti_jika_selesai=False)

    print("\n=== A. Tanpa tindakan ===")
    print(ringkasan(a))
    print("\n=== B. Ditangani ===")
    print(ringkasan(b))
    print()
    cetak_tujuan(b)
    simpan_csv(a, os.path.join(FOLDER_HASIL, "darurat_tanpa_tindakan.csv"))
    simpan_csv(b, os.path.join(FOLDER_HASIL, "darurat_ditangani.csv"))

    fig, ax = plt.subplots(figsize=(10, 4.5))
    for kondisi, label in ((a, "Tanpa tindakan"), (b, "Ditangani")):
        ax.plot([p["time"] for p in kondisi["history"]], [p["ht_outlet"] for p in kondisi["history"]], label=label)
    ax.axhline(98, color="red", linestyle="--", linewidth=1)
    ax.set_xlabel("Waktu simulasi (detik)")
    ax.set_ylabel("Suhu HT keluar jaket (°C)")
    ax.set_title("Misi 3: kegagalan pompa SW #1")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(FOLDER_HASIL, "darurat.png"), dpi=130)
    if ARGS.tampil:
        plt.show()


# ---------------------------------------------------------------- Demo 3: Mode bebas

def demo_bebas():
    s = SCENARIOS["sandbox"]["buat_kondisi"]()

    def tiap(s, t):
        if t == 60:
            s["telegraph_pct"] = 40   # turunkan beban di detik ke-60

    jalankan(s, 150, tiap, berhenti_jika_selesai=False)
    laporan(s, "bebas")
    grafik(s, os.path.join(FOLDER_HASIL, "bebas.png"), tampil=ARGS.tampil)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Simulator sistem pendingin kapal (versi Python)")
    parser.add_argument("demo", nargs="?", default="misi1", choices=["misi1", "darurat", "bebas"])
    parser.add_argument("--tampil", action="store_true", help="tampilkan jendela grafik")
    ARGS = parser.parse_args()

    if not ARGS.tampil:
        plt.switch_backend("Agg")   # tanpa jendela, grafik hanya disimpan
    os.makedirs(FOLDER_HASIL, exist_ok=True)

    {"misi1": demo_misi1, "darurat": demo_darurat, "bebas": demo_bebas}[ARGS.demo]()
    print(f"\nGrafik dan CSV tersimpan di folder '{FOLDER_HASIL}/'")
